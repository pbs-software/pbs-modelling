# ***********************************************************
# calcFib2:
#   Compute Fibonacci numbers iteratively using a .Call() 
#   call to C code
# Arguments:
#   n   - final nth fibonacci number to calculate
#   len - length of output vector with previous fibonacci numbers
# -----------------------------------------------------------
calcFib2 <- function(n, len=1)
{
	retArr <- numeric(len)
	out <- .Call("fib2", as.integer(n), as.integer(len), PACKAGE="PBStry")
	return(out)
}
